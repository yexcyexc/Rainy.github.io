import NProgress from 'nprogress';

export default NProgress;
